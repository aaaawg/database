﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{
    public partial class UserInfoOrder : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        public UserInfoOrder()
        {
            InitializeComponent();

            connection.Open();
            string query = "select 주문일, 도서명, 구분, 사용포인트, 결제가격 from 도서, 주문 where 도서.ISBN = 주문.ISBN and 아이디 = '"
                + User.LoginId + "' order by 주문일 asc;";
            cmd = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }
    }
}

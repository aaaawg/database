﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{
    public partial class MainAdmin : Form
    {
        public MainAdmin()
        {
            InitializeComponent();
            open(new AdminBook());
            Text = "YBook 도서 관리";
        }

        private Form form1 = null;
        private void open(Form form)
        {
            if (form1 != null)
                form1.Close();
            form1 = form;
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            panel2.Controls.Add(form);
            form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            open(new AdminBook());
            Text = "YBook 도서 관리";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            open(new AdminSub());
            Text = "YBook 이용권 관리";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            open(new AdminQnA());
            Text = "YBook 문의 관리";
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

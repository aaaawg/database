﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{
    public partial class UserInfoProfile : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");

        public UserInfoProfile()
        {
            InitializeComponent();
            string sub;
            User user = new DataManager().UserInfo();
            sub = user.Sub;
            if (sub.Trim() == "")
            {
                label1.Text = "사용중인 이용권이 없습니다.";
                label2.Visible = false;
                label10.Visible = false;
                button1.Visible = true;
            }
            else
            {
                label1.Text = user.Sub + "일 이용권";
                label10.Text = user.EDate.Substring(0, user.EDate.Length - 11);
                button1.Visible = false;
            }
            textBox1.Text = user.Password;
            textBox2.Text = user.Name;
            textBox3.Text = user.Age.ToString();
            label9.Text = user.Point.ToString();
            label8.Text = User.LoginId;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new UserInfoSub().ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "delete from 회원 where 아이디 = '" + User.LoginId + "';";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("탈퇴되었습니다.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "update 회원 set 비밀번호 = '" + textBox1.Text + "', 이름 = '" + textBox2.Text + "', 나이 = "
                + Convert.ToInt32(textBox3.Text) + " where 아이디 = '" + User.LoginId + "';";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("회원정보가 수정되었습니다.");
        }
    }
}

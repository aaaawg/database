﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{
    public partial class UserBookOrder : Form
    {
        int p = 0;
        string type;
        int point = 0;
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
        public UserBookOrder()
        {
            InitializeComponent();
            label1.Text = new DataManager().BookInfo(Book.SISBN).Title;
            label2.Text = new DataManager().BookPrice(Book.SISBN, "소장") + "원";
            type = "소장";
            if (new DataManager().BookPrice(Book.SISBN, "대여").Trim() == "")
            {
                checkBox2.Visible = false;
                label3.Text = "";
                checkBox1.Enabled = false;
            }

            else
                label3.Text = new DataManager().BookPrice(Book.SISBN, "대여") + "원";
            if (label3.Text.Trim() == "")
                checkBox2.Visible = false;
            else
                checkBox2.Visible = true;
            label8.Visible = false;

            if (checkBox1.Checked)
            {
                label5.Text = label2.Text;
                checkBox2.Enabled = false;
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                label5.Text = label2.Text;
                checkBox2.Enabled = false;
                type = "소장";
            }
            else
            {
                checkBox2.Enabled = true;
                label5.Text = "";
                label8.Text = "";
                textBox1.Text = "0";
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                label5.Text = label3.Text;
                checkBox1.Checked = false;
                checkBox1.Enabled = false;
                type = "대여";
            }
            else
            {
                checkBox1.Enabled = true;
                label5.Text = "";
                label8.Text = "";
                textBox1.Text="0";
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            label8.Visible = true;
            int price = 0;
            if(label5.Text == label2.Text)
                price = Convert.ToInt32(new DataManager().BookPrice(Book.SISBN, "소장"));
            else if(label5.Text == label3.Text)
                price = Convert.ToInt32(new DataManager().BookPrice(Book.SISBN, "대여"));
            point = Convert.ToInt32(textBox1.Text);
            p = price - point;
            label8.Text = p + "원";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "insert into 주문(아이디, ISBN, 구분, 사용포인트, 결제가격) values('"
                + User.LoginId + "','" + Book.SISBN + "', '" + type + "', " + point + ", " + p + ");";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
            query = "update 회원 set 포인트 = 포인트 - " + point + "+ round(" + p + "* 0.03,0) where 아이디 = '" + User.LoginId + "';";
            command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("결제되었습니다.");
            this.Close();
        }
    }
}

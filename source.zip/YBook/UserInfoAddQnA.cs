﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{
    public partial class UserInfoAddQnA : Form
    {
        public UserInfoAddQnA()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
            connection.Open();

            string query = "insert into 문의글(아이디, 제목, 내용) values('"
                + User.LoginId + "','" + textBox1.Text + "', '" + textBox2.Text + "');";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("문의글이 등록되었습니다.");
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace YBook
{
    public partial class Join : Form
    {
        public Join()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
            connection.Open();

            string query = "insert into 회원(아이디, 비밀번호, 이름, 나이) values('"
                + textBox1.Text + "','" + textBox2.Text + "', '" + textBox3.Text + "', '"
                + textBox4.Text + "');";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("회원가입 성공");
            this.Close();
        }
    }
}

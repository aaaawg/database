﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{
    public partial class UserAudioBook : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        public UserAudioBook()
        {
            InitializeComponent();
            label1.Text = new DataManager().BookInfo(Book.SISBN).Title;
            label2.Text = new DataManager().BookAuthor(Book.SISBN);

            connection.Open();
            string query = "select 회차, 낭독자, 재생시간 from 오디오북 where ISBN =" + Book.SISBN + ";";
            cmd = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }
    }
}

﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{
    public partial class UserInfoSub : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
        public UserInfoSub()
        {
            InitializeComponent();
            label3.Text = "";
            label4.Text = "";
            string query = "select * from 이용권;";
            connection.Open();
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
                comboBox1.Items.Add(reader[0].ToString());

            reader.Close();
            connection.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string query = "select * from 이용권 where 종류 = " + comboBox1.Text + ";"
;           connection.Open();
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                label3.Text = reader[1] + "원";
                label4.Text = "오디오북 " + reader[0].ToString() + "일 무제한 이용권";
            }
            reader.Close();
            connection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "update 회원 set 이용권_종류 = " + comboBox1.Text + ", 이용권_주문일 = now() where 아이디 = '"
                + User.LoginId + "';";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show(comboBox1.Text+"일 이용권이 결제되었습니다.");
            this.Close();
        }
    }
}

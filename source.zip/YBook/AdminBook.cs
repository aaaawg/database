﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{
    public partial class AdminBook : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();

        public AdminBook()
        {
            InitializeComponent();
            refresh();
            audioBookRefresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new AdminAddBook().ShowDialog();
        }

        public void refresh()
        {
            panel1.Visible = false;
            connection.Open();
            string query = "select 도서.ISBN, 도서명, count(구분) as 판매량 from 도서 left outer join 주문 on 주문.ISBN = 도서.ISBN" +
                " and 구분='소장' group by 도서.ISBN;";
            cmd = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }

        public void audioBookRefresh()
        {
            connection.Open();
            string query = "select * from 오디오북 where ISBN = " + Book.SISBN + ";";
            cmd = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView2.AutoGenerateColumns = false;
            dataGridView2.DataSource = dt;
            connection.Close();
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            if (textBox3.Text.Trim() == "낭독자 입력")
                textBox3.Text = "";
            if (textBox4.Text.Trim() == "")
                textBox4.Text = "재생시간 입력";
        }

        private void textBox4_Click(object sender, EventArgs e)
        {
            if (textBox4.Text.Trim() == "재생시간 입력")
                textBox4.Text = "";
            if (textBox3.Text.Trim() == "")
                textBox3.Text = "낭독자 입력";
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex == -1 || e.ColumnIndex == -1) return;
            panel1.Visible = true;
            textBox1.Text = "";
            textBox2.Text = "";
            Book.SISBN = (int)dataGridView1.Rows[e.RowIndex].Cells[0].Value;
            audioBookRefresh();
            label1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            Book book = new DataManager().BookInfo(Book.SISBN);
            label3.Text = new DataManager().BookAuthor(Book.SISBN);
            label5.Text = book.Publisher;
            label7.Text = book.PDate;
            label9.Text = Book.SISBN.ToString();
            label11.Text = book.Price + "원";

            if (new DataManager().BookDiscount(Book.SISBN, "소장").Trim() != "")
            {
                checkBox1.Checked = true;
                textBox1.Text = new DataManager().BookDiscount(Book.SISBN, "소장");
            }
            else
                checkBox1.Checked = false;

            if (new DataManager().BookDiscount(Book.SISBN, "대여").Trim() != "")
            {
                checkBox2.Checked = true;
                textBox2.Text = new DataManager().BookDiscount(Book.SISBN, "대여");
            }
            else
                checkBox2.Checked = false;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (new DataManager().BookDiscount(Book.SISBN, "대여").Trim() != "" && checkBox2.Checked == true)
            {
                connection.Open();
                string query = "update 도서_할인율 set 할인율 = " + Convert.ToInt32(textBox2.Text)
                    + " where ISBN = '" + Book.SISBN + "' and 구분 = '대여';";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                refresh();
            }
            else if (new DataManager().BookDiscount(Book.SISBN, "대여").Trim() == "" && checkBox2.Checked == true)
            {
                connection.Open();
                string query = "insert into 도서_할인율 values(" + Book.SISBN + ", '대여', " + textBox2.Text + ");";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                refresh();
            }
            else if (checkBox2.Checked != true) 
            {
                connection.Open();
                string query = "delete from 도서_할인율 where ISBN = " + Book.SISBN + " and 구분 = '대여';";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                refresh();
            }

            if (new DataManager().BookDiscount(Book.SISBN, "소장").Trim() != "" && checkBox1.Checked == true)
            {
                connection.Open();
                string query = "update 도서_할인율 set 할인율 = " + Convert.ToInt32(textBox1.Text)
                    + " where ISBN = '" + Book.SISBN + "' and 구분 = '소장';";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                refresh();
            }
            else if (new DataManager().BookDiscount(Book.SISBN, "소장").Trim() == "" && checkBox1.Checked == true)
            {
                connection.Open();
                string query = "insert into 도서_할인율 values(" + Book.SISBN + ", '소장', " + textBox1.Text + ");";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                refresh();
            }
            else if (checkBox1.Checked != true)
            {
                connection.Open();
                string query = "delete from 도서_할인율 where ISBN = " + Book.SISBN + " and 구분 = '소장';";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                refresh();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "delete from 도서 where ISBN = " + Book.SISBN + ";";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
            refresh();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "insert into 오디오북 values(" + Book.SISBN + ", " + numericUpDown1.Value + ", '"
                + textBox3.Text + "', '" + textBox4.Text + "');";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
            audioBookRefresh();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            refresh();
        }
    }
}

﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YBook
{
    class DataManager
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
        public DataManager()
        {
            connection.Open();
        }

        ~DataManager()
        {
            connection.Close();
        }
        public Book BookInfo(int isbn)
        {
            string query = "select * from 도서 where ISBN=" + isbn + ";";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();
            reader.Read();
            Book bookInfo = new Book();
            bookInfo.Title = reader[1].ToString();
            bookInfo.Publisher = reader[2].ToString();
            bookInfo.PDate = reader[3].ToString();
            bookInfo.Price = (int)reader[4];
            reader.Close();
            return bookInfo;
        }
        public string BookAuthor(int isbn)
        {
            string query = "select * from 도서_저자 where ISBN=" + isbn + ";";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();
            Book bookInfo = new Book();

            while (reader.Read())
            {
                bookInfo.Author += reader[1].ToString() + ", ";
            }

            bookInfo.Author = bookInfo.Author.Substring(0, bookInfo.Author.Length - 2);
            reader.Close();

            return bookInfo.Author;
        }

        public string BookPrice(int isbn, string type)
        {
            try
            {
                string query = "select 도서.ISBN, 구분, round(가격 * (1 - 할인율 / 100), 0) as 판매가 from 도서, 도서_할인율 where 도서_할인율.ISBN = 도서.ISBN and 도서.ISBN = "
                    + isbn + " and 구분 = '" + type + "';";
                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataReader reader = command.ExecuteReader();
                reader.Read();
                string price = reader[2].ToString();
                reader.Close();

                return price;
            }
            catch (Exception)
            {
                return "";
            }
        }

        public User UserInfo()
        {
            string query = "select 비밀번호, 이름, 나이, 포인트, 이용권_종류, date_add(이용권_주문일, interval 이용권_종류 day) as 이용권_만료일 from 회원 where 아이디 = '" + User.LoginId + "';";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();
            User userInfo = new User();
            reader.Read();
            userInfo.Password = reader[0].ToString();
            userInfo.Name = reader[1].ToString();
            userInfo.Age = (int)reader[2];
            userInfo.Point = (int)reader[3];
            userInfo.Sub = reader[4].ToString();
            userInfo.EDate = reader[5].ToString();
            reader.Close();

            return userInfo;
        }

        public string BookDiscount(int isbn, string type)
        {
            try
            {
                string query = "select * from 도서_할인율 where ISBN = " + isbn + " and 구분 = '" + type + "';";
                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataReader reader = command.ExecuteReader();
                reader.Read();
                string discount = reader[2].ToString();
                reader.Close();

                return discount;
            }
            catch (Exception)
            {
                return "";

            }
        }
    }
}

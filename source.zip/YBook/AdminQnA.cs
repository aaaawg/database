﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{
    public partial class AdminQnA : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        int no = 0;

        public AdminQnA()
        {
            InitializeComponent();
            refresh();
        }

        public void refresh()
        {
            panel1.Visible = false;
            connection.Open();
            string query = "select * from 문의글 order by 작성일 asc;";
            cmd = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex == -1 || e.ColumnIndex == -1) return;
            panel1.Visible = true;
            label1.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            label2.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            no = (int)dataGridView1.Rows[e.RowIndex].Cells[0].Value;

            if (dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString().Trim() != "")
            {
                label4.Text = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
                label5.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            }
            else
            {
                label4.Text = "";
                label5.Text = "";
                textBox1.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "update 문의글 set 답변_내용 = '" + textBox1.Text + "', 답변_작성일 = now(), 답변_사원번호 = "
                + User.LoginId + " where 글번호 = " + no + ";";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("답변이 등록되었습니다.");
        }

        private void label6_Click(object sender, EventArgs e)
        {
            refresh();
        }
    }
}

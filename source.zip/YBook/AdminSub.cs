﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{
    public partial class AdminSub : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        string query;
        public AdminSub()
        {
            InitializeComponent();
            refresh();

            connection.Open();
            query = "select 아이디, 이용권_종류 as 종류, 이용권_주문일 as 주문일, date_add(이용권_주문일, interval 이용권_종류 day) as 만료일" +
                " from 회원 where 이용권_주문일 is not null;";
            cmd = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView2.DataSource = dt;
            connection.Close();
        }
        public void refresh()
        {
            connection.Open();
            query = "select * from 이용권;";
            cmd = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "insert into 이용권 values('" + textBox1.Text + "','" + textBox2.Text + "');";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("이용권이 추가되었습니다.");
                refresh();
            }
            catch (Exception)
            {
                MessageBox.Show("이용권 추가를 실패했습니다.");
                connection.Close();
            }
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex == -1 || e.ColumnIndex == -1) return;
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "delete from 이용권 where 종류 = '" + textBox1.Text + "';";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("이용권이 삭제되었습니다.");
            textBox1.Text = "";
            textBox2.Text = "";
            refresh();
        }
    }
}

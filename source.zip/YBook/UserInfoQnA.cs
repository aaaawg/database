﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{
    public partial class UserInfoQnA : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();

        public UserInfoQnA()
        {
            InitializeComponent();
            refresh(); 
        }

        public void refresh()
        {
            panel1.Visible = false;
            connection.Open();
            string query = "select * from 문의글 where 아이디 = '" + User.LoginId + "' order by 작성일 asc;";
            cmd = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            connection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new UserInfoAddQnA().ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            refresh();
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex == -1 || e.ColumnIndex == -1) return;
            panel1.Visible = true;
            label2.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox1.Text= dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();

            if (dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString().Trim() != "")
            {
                groupBox2.Visible = true;
                label3.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            }
            else
                groupBox2.Visible = false;
        }
    }
}

﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{

    public partial class UserBook : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();

        public UserBook()
        {
            InitializeComponent();
            refresh("전체");
            reviewRefresh();
        }

        public void refresh(string c)
        {
            panel1.Visible = false;
            string query;
            connection.Open();
            if(c.Trim()=="대여")
                query = "select 도서.ISBN, 도서명, 출판사, 출간일, 가격 from 도서, 도서_할인율 where 도서.ISBN = 도서_할인율.ISBN and 구분 = '대여';";
            else
                query = "select * from 도서;";
            cmd = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView2.AutoGenerateColumns = false;
            dataGridView2.DataSource = dt;
            connection.Close();
        }

        public void reviewRefresh()
        {
            dataGridView3.DataSource = null;
            connection.Open();
            string query = "select 점수, 내용, 작성일 from 리뷰, 도서 where 리뷰.ISBN = 도서.ISBN and 리뷰.ISBN =" + Book.SISBN + ";";
            cmd = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView3.DataSource = dt;
            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "insert into 리뷰(아이디, ISBN, 점수, 내용) values('"
                + User.LoginId + "','" + Book.SISBN + "', '" + numericUpDown1.Value + "', '"
                + textBox1.Text + "');";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("리뷰가 등록되었습니다.");
            reviewRefresh();
        }

        private void dataGridView2_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex == -1 || e.ColumnIndex == -1) return;
            panel1.Visible = true;
            Book.SISBN = (int)dataGridView2.Rows[e.RowIndex].Cells[0].Value;
            reviewRefresh();
            label1.Text = dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString();
            Book book = new DataManager().BookInfo(Book.SISBN);
            label2.Text = new DataManager().BookAuthor(Book.SISBN);
            label9.Text = book.Publisher;
            label10.Text = book.PDate;
            label11.Text = Book.SISBN.ToString();
            label12.Text = new DataManager().BookPrice(Book.SISBN, "소장") + "원";
            label13.Text = new DataManager().BookPrice(Book.SISBN, "대여");
            if (label13.Text.Trim() != "")
            {
                label8.Visible = true;
                label13.Text = new DataManager().BookPrice(Book.SISBN, "대여") + "원";
            }
            else
                label8.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sub = new DataManager().UserInfo().Sub;
            if (sub.Trim() == "")
                MessageBox.Show("오디오북을 이용할 수 없습니다. 이용권을 구매해주세요.");
            else
                new UserAudioBook().ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new UserBookOrder().ShowDialog();
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            if(comboBox1.Text =="대여")
                refresh("대여");
            else
                refresh("전체");
        }
    }
}

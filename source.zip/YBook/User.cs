﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YBook
{
    class User
    {
        public static string LoginId { get; set; }
        public string Id { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Sub { get; set; }
        public string EDate { get; set; }
        public int Point { get; set; }
    }
}

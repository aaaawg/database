﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YBook
{
    public partial class AdminAddBook : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Database=ybook;Uid=root;Pwd=a025763;");
        public AdminAddBook()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox3.Text);
            textBox3.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            connection.Open();
            string query = "insert into 도서 values('"
                + textBox1.Text + "','" + textBox2.Text + "', '" + textBox5.Text + "', '"
                + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "', '" + textBox4.Text + "');";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();

            if (checkBox1.Checked == true && textBox6.Text.Trim() != "")
            {
                query = "insert into 도서_할인율 values('" + textBox1.Text + "', '소장', " + textBox6.Text + ");";
                command = new MySqlCommand(query, connection);
                command.ExecuteNonQuery();
            }
            if (checkBox2.Checked == true && textBox7.Text.Trim() != "")
            {
                query = "insert into 도서_할인율 values('" + textBox1.Text + "', '대여', " + textBox7.Text + ");";
                command = new MySqlCommand(query, connection);
                command.ExecuteNonQuery();
            }

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                query = "insert into 도서_저자 values('" + textBox1.Text + "', '" + listBox1.Items[i].ToString() + "');";
                command = new MySqlCommand(query, connection);
                command.ExecuteNonQuery();
            }

            connection.Close();
            MessageBox.Show("도서가 등록되었습니다.");
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int i = 0;
            i = listBox1.SelectedIndex;
            listBox1.Items.RemoveAt(i);
        }
    }
}
